Repository for the course '193.180 Computer Graphics (VU 4,0) 2025W' demo project created by:

Goup RenderForge:

- Ali Kömürcü - 12448700

- Nagy Áron Artúr - 12512136

GPUs used:

- NVIDIA GTX 1660
- NVIDIA Quadro T2000
